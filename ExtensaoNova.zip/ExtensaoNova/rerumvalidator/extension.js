// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
const vscode = require('vscode');
const { execValidation } = require('./state-transition');

// This method is called when your extension is activated
// Your extension is activated the very first time the command is executed

/**
 * @param {vscode.ExtensionContext} context
 */

function activate(context) {

    console.log('Hello World from rerum-validator!');   
	const outputChannel = vscode.window.createOutputChannel('rerum-validator');
    const provider = new HelloWorldProvider();  
    vscode.window.registerTreeDataProvider('mySideBarview', provider);
    const diagnosticCollection = vscode.languages.createDiagnosticCollection('rerum-validator');

    let disposableExt = vscode.workspace.onDidOpenTextDocument(async (event) => {
        let document = event;
        if (document.fileName.endsWith('.rerum')) {
            const diagnostics = await execValidation(document.getText());
            diagnosticCollection.set(document.uri, diagnostics);
        }
    });

    context.subscriptions.push(disposableExt);

outputChannel.show();

}

class HelloWorldProvider {
    getTreeItem(element) {
        return new vscode.TreeItem(element);
    }

    getChildren(element) {
        if(!element) {
            return Promise.resolve(['Hello World']);

        }
        return Promise.resolve([]);

    }
}

function deactivate() {}

module.exports = {

    activate,
    deactivate
}
