const fs = require('fs');
const KEYWORDS = ['class', 'string', 'attribute', 'extends', 'struct', 'long', 'integer', 'module', 'include', 'typedef', 'listof'];
const RESERVED_CHARACTERS = ['{', '}', ';', '(', ')'];
const TYPES = ['string', 'long', 'integer'];

exports.TYPES = TYPES;
exports.getAllOdlFiles = (directory = './') => {
  // verify folder and subfolders for olds files
  const files = fs.readdirSync(directory);
  const odlFiles = files.filter(file => file.endsWith('.odl'));
  return odlFiles;
}

exports.parseFileTokens = (fileContent) => {
  const lines = fileContent.split('\n');

  const tokens = [];
  let currentLine = 1;
  for(const line of lines) {
    const parsedLine = parseLine(line);
    for(let i=0; i<parsedLine.length; i++) {
      const token = parsedLine[i];
      const lastToken = i > 0 ? parsedLine[i-1].tokenValue : null;
      const tokenType = getTokenType(token.tokenValue,lastToken);
      tokens.push({ token: token.tokenValue, tokenType, line: currentLine, column: token.initialColumn});
    }
    currentLine++;
  }

  return tokens;
}

function parseLine(line) {
  const tokens = [];
  let startColumn = 0;

  const words = line.trim().split(/\s+/);

  for (const word of words) {
    const initialColumn = line.indexOf(word, startColumn);
      // split by characters to generate multi tokens
      const characters = word.split(/(\b\w+\b|[\{\}\(\);])/g).filter(char => char.trim() !== '');
      for(const char of characters) {
        tokens.push({
          tokenValue: char,
          initialColumn: initialColumn
        });
        startColumn = initialColumn + char.length;
      }
   
  }

  return tokens;
}

function getTokenType(token, lastToken) {
  // Assume that 'keywords' is an array of language keywords
  if(RESERVED_CHARACTERS.includes(token)){
    return 'CHARACTERS';
  }
  else if (TYPES.includes(token)) {
    return 'TYPE';
  }
  if (KEYWORDS.includes(token)) {
    return 'KEYWORD';
  } else if (/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(token)) {
    if(lastToken === 'attribute'){
      return 'TYPE'
    }
    return 'IDENTIFIER';
  } else {
    // Add more checks for different token types as needed
    return 'UNKNOWN';
  }
}