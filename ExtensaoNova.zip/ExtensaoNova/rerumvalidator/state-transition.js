const fs = require('fs');
const { parseFileTokens} = require('./utils');

function parseStateMachineFile(fileName) {
  const fileContent = fs.readFileSync(fileName, 'utf8');
  const lines = fileContent.split('\n');
  // parse csv to json
  const transitions = [];
  for(const line of lines) {
    const values = line.split(';');
    const transition = {
      event: values[0].replace('\r',''),
      initialState: values[1].replace('\r',''),
      finalState: values[2].replace('\r','')
    };
    transitions.push(transition);
  }
  return JSON.parse(JSON.stringify(transitions));
}


function parseContent(odlContent, stateMachineFile) {
  const tokens = parseFileTokens(odlContent)

  const transitions = parseStateMachineFile(stateMachineFile);
  // console.log(transitions)
  // console.log(tokens)
  let currentState = '';
  let currentEvent = 'begin'
   
  let verifiedTokens = [];
  for (const token of tokens) {
    const transition = transitions.find(transition => {
      if(currentEvent==='end'){
        return token;
      }
      const valueToCompare = token.token===';'?'comma':token.token;

      const isSameInitialState = transition.initialState === currentState;
      const isSameFinalState = transition.finalState === valueToCompare;
      const canBeIdentifier = token.tokenType==='IDENTIFIER' && currentState!=='comma'

      // console.log(`Token: ${token.token} isSameInitialState: ${isSameInitialState} (${currentState}) isSameFinalState: ${isSameFinalState} ${transition.finalState} ${transition.initialState} ${transition.event} ${token.tokenType}`)
      return isSameInitialState && ( (canBeIdentifier  || token.tokenType==='TYPE')|| isSameFinalState );
    });
    const isPosibleEndToken = transitions.find(transition => {
      const valueToCompare = token.token===';'?'comma':token.token;
      if(valueToCompare==='comma')
      return transition.initialState === valueToCompare && transition.event === 'end';
    })
    
    if(!transition && !isPosibleEndToken) {
      return token;
    }
    // console.log(transition, token.token)
    if(transition){
      verifiedTokens.push(token)
    }
    
    if(isPosibleEndToken && !transition){
      if(verifiedTokens.length!==tokens.length){
        return token
      }
      return;
    }

    currentState = transition.finalState;
    currentEvent = transition.event;
  }

}




exports.execValidation = async (odlContent, stateMachineFile) => { 
  const error = parseContent(odlContent, stateMachineFile)
  return error
}